using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    
    public GameObject[] enemies;

    public GameObject[] obstacles;
    

    

    
}
