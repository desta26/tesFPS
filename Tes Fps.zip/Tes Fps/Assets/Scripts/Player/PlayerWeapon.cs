using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWeapon : MonoBehaviour
{
    [SerializeField] protected Weapon weapon;


    private void Awake()
    {
        AssignWeapon();
    }

    private void AssignWeapon()
    {
        weapon = GetComponentInChildren<Weapon>();
    }

    public void Shoot()
    {
        if (weapon != null)
            weapon.TryShooting();
    }

    public void StopShooting()
    {
        if (weapon != null)
            weapon.StopShooting();
    }
}
