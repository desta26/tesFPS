using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Player : MonoBehaviour, IHittable, IObject
{
    [field: SerializeField]
    public int Health { get; set; }

    private bool dead = false;

    [field: SerializeField]
    public UnityEvent OnDie { get; set; }
    [field: SerializeField]
    public UnityEvent OnGetHit { get; set; }

    public void GetHit(int damage, GameObject damageDealer)
    {
        if (dead == false)
        {
            GameManager.instance.AddScore(damage);
            OnGetHit?.Invoke();
            
        }
    }

    
}
