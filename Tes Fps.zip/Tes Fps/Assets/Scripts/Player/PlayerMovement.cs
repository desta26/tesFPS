using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private Camera cam;
    [SerializeField] private float range = 50f;
    [SerializeField] float inAccuracyDistance = 5f;

    protected CharacterController controller;
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float jumpHeight = 3f;

    [SerializeField]
    protected Vector3 playerVelocity;
    protected bool isGrounded;
    protected Vector2 movementDirection;
    protected float gravity = -9.81f;
    protected float gravityMultiplier = 3f;


    private void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    public void OnMove(Vector2 movementInput)
    {
        Vector3 moveDir = Vector3.zero;
        moveDir.x = movementInput.x;
        moveDir.z = movementInput.y;

        controller.Move(transform.TransformDirection(moveDir) * moveSpeed * Time.deltaTime);
        controller.Move(playerVelocity * Time.deltaTime);

    }



    private void CalculateGravity()
    {
        if (!isGrounded)
        {
            gravityMultiplier = 3f;
            playerVelocity.y += gravity * gravityMultiplier * Time.deltaTime;

        }
        else if (isGrounded && playerVelocity.y < 0)
        {
            gravityMultiplier = 0;
            playerVelocity.y = -0.8f;
        }
    }

    private void Update()
    {
        isGrounded = controller.isGrounded;
    }

    private void FixedUpdate()
    {
        CalculateGravity();
        
    }

    public void OnJump()
    {
        if (isGrounded)
        {
            playerVelocity.y = Mathf.Sqrt(jumpHeight * -3.0f * gravity);
        }
    }

    public void HitEffect() {
        if (isGrounded)
        {
            playerVelocity.y = Mathf.Sqrt(jumpHeight * -1.0f * gravity);
        }
    }

    
}
