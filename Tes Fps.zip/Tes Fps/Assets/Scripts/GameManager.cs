using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.Events;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public int Score;
    public TextMeshProUGUI scoreText;
    public UnityEvent OnUpdateScore;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(instance);
        }
        else {
            Destroy(this);
        }
    }

    public void UpdateScore() {
        scoreText.text = "Score : " + Score.ToString();
    }

    public void AddScore(int value) {
        Score += value;
        OnUpdateScore?.Invoke();
    }

    public void DecreaseScore(int value)
    {
        Score -= value;
        OnUpdateScore?.Invoke();
    }

}
