using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Obstacle : MonoBehaviour, IHittable, IObject
{
    [field: SerializeField]
    public int Health { get; private set; } = 1;
    [SerializeField] private int score;


    [field: SerializeField]
    public UnityEvent OnGetHit { get; set; }

    [field: SerializeField]
    public UnityEvent OnDie { get; set; }


    public void GetHit(int damage, GameObject damageDealer)
    {
        Debug.Log("GetHit");
    }

    public void ApplyScore()
    {
        GameManager.instance.DecreaseScore(score);
    }

    IEnumerator WaitToDie()
    {
        yield return new WaitForSeconds(.2f);
        Destroy(gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player") {
            OnDie?.Invoke();
            StartCoroutine(WaitToDie());
            Debug.Log("kurangi score");
        }
    }

    
}
