using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Enemy : MonoBehaviour, IHittable, IObject
{
    
    [field: SerializeField]
    public int Health { get; private set; } = 3;
    [SerializeField] private int score;

    private bool dead = false;

    [field: SerializeField]
    public UnityEvent OnGetHit { get; set; }

    [field: SerializeField]
    public UnityEvent OnDie { get; set; }


    public void GetHit(int damage, GameObject damageDealer)
    {
        if (dead == false)
        {
            Health -= damage;
            OnGetHit?.Invoke();
            if (Health <= 0)
            {
                dead = true;
                OnDie?.Invoke();
                StartCoroutine(WaitToDie());

            }
        }

    }

    public void ApplyScore() {
        GameManager.instance.AddScore(score);
    }

    IEnumerator WaitToDie()
    {
        yield return new WaitForSeconds(.54f);
        Destroy(gameObject);
    }

}
