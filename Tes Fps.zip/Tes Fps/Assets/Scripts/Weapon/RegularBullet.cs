using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RegularBullet : Bullet
{
    protected Rigidbody rb;

    public override BulletData BulletData
    {
        get => base.BulletData;
        set
        {
            base.BulletData = value;
            rb = GetComponent<Rigidbody>();
            rb.drag = BulletData.Friction;
        }
    }

    private void Start()
    {
        Invoke("DestroyBullet", 1f);
    }

    void DestroyBullet() {
        Destroy(gameObject);
    }

    private void FixedUpdate()
    {
        if (rb != null && BulletData != null)
        {
            Transform cam = Camera.main.transform;
            Ray ray = new Ray(cam.position, cam.forward);

            transform.GetComponent<Rigidbody>().velocity = ray.direction.normalized * BulletData.BulletSpeed ;
            //transform.GetComponent<Rigidbody>().AddRelativeForce(new Vector3(0,BulletData.BulletSpeed,0) );//
        }
    }

    private void OnTriggerEnter(Collider collision)
    {
        var hittable = collision.GetComponent<IHittable>();
        hittable?.GetHit(bulletData.Damage, gameObject);

        if (collision.gameObject.layer == LayerMask.NameToLayer("Obstacle"))
        {
            HitObstacle();
        }
        else if (collision.gameObject.layer == LayerMask.NameToLayer("Enemy"))
        {
            HitEnemy();
        }
        Destroy(gameObject);
    }

    private void HitEnemy()
    {
        Debug.Log("Hitting enemy");
    }

    private void HitObstacle()
    {
        Debug.Log("Hitting obstacle");
    }
}
