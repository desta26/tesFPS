using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Spawner : MonoBehaviour
{
    public obstacle Obstacle;
    public enum obstacle {
        enemy,
        obstacle
    }

    public float timeToSpawn = 5f;

    private SpawnManager spawnManager;
    private bool readyToSpawn = false;

    private void Awake()
    {
        spawnManager = GetComponentInParent<SpawnManager>();
        StartCoroutine(SpawnEnemy(1));
    }

    private void Update()
    {
        if (transform.childCount == 0)
        {
            if (readyToSpawn == false) {
                Spawn();
            }
        }

    }

    private void Spawn() {
        readyToSpawn = true;
        StartCoroutine(SpawnEnemy(timeToSpawn));
    }

    public IEnumerator SpawnEnemy(float timer)
    {
        readyToSpawn = true;

        yield return new WaitForSeconds(timer);
        int idx = Random.Range(0, spawnManager.enemies.Length);
        if (Obstacle == obstacle.enemy)
        {
            GameObject obj = Instantiate(spawnManager.enemies[idx], transform.position, spawnManager.enemies[idx].transform.rotation);
            obj.transform.parent = transform;
        }
        else if (Obstacle == obstacle.obstacle) {
            GameObject obj = Instantiate(spawnManager.obstacles[idx], transform.position, spawnManager.obstacles[idx].transform.rotation);
            obj.transform.parent = transform;
        }
      
        readyToSpawn = false;
    }
}
